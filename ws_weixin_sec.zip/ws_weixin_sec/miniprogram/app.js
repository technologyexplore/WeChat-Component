//app.js
App({
  onLaunch: function () {
    console.log("监听小程序启动");
    this.globalData = {}
  },
  onShow: function () {
  //页面从后台显示到前台(程序第一次执行,或者用户按下home键以后,又打开了微信,进入下批程序)
    console.log("页面显示出来了");
  },
  onHide: function(){
    console.log("监听小程序切换");
  },
  onError: function () {
    console.log("监听错误");
  },
  onPageNotFound: function () {
    console.log("监听页面不存在");
  }
})
