Component({
 /**
   * 组件的生命周期
   */
  created: function () {
    //在组件实例刚刚被创建时执行
    console.log("自定义组件创建");
  },  
  attached: function () {
    // 在组件实例进入页面节点树时执行
    console.log("自定义组件进入页面节点树");
  },
  ready: function () {
    // 在组件在视图层布局完成后执行
    console.log("自定义组件在视图层布局完成");
  },
  moved: function () {
    // 在组件实例被移动到节点树另一个位置时执行
  },
  detached: function () {
    // 在组件实例被从页面节点树移除时执行
  },
  error: function () {
    // 每当组件方法抛出错误时执行
  },

  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
})
