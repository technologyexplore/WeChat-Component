Page({
  data: { 
    message: "hello",
    name:"张三",
    flag:false,
    condition: Math.floor(Math.random()*3+1),
    items: [
      { name: "商品A" },
      { name: "商品B" },
      { name: "商品B" },
      { name: "商品C" },
      { name: "商品D" }
    ],
    person:{
      name:"李四",
      phone:"13876567890",
      address:"中国广州"
    }
  }
  
})