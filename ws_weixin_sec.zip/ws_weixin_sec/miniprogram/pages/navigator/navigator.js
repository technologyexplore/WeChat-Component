Page({
  data: {
   
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: ''
  }
})