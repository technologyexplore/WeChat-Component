var initData = 'this is first line\nthis is second&nbsp;line';
var extraLine = [];
Page({
  data: {
    text: initData,
    nodes: [{
      name: 'div',
      attrs: {
        class: 'div_class',
        style: 'line-height: 60px; color: red;'
      },
      children: [{
        type: 'text',
        text: 'Hello&nbsp;World!'
      }]
    }],
    percentValue: 0,

    background: ['demo-text-1', 'demo-text-2', 'demo-text-3'],
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 2000,//自动播放间隔时长
    duration: 300,//幻灯片切换时长
    toView: 'red',
    scrollTop: 0
  },
  onLoad() {
    //let 声明局部变量，最近的大括号里面才能使用
    let timer;
    timer = () => {
      setTimeout(() => {
        // const声明常量，也具有块级作用域
        const value = this.data.percentValue;
        this.setData({
          percentValue: value < 100 ? value + 10 : value
        });
        timer()
      }, 2000);
    }
    timer();
  },
  /**
     * swiper api
     */
  changeIndicatorDots: function (e) {
    console.log('切换指示点开关');
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay: function (e) {
    console.log('切换自动播放开关');
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange: function (e) {
    console.log(`调整自动播放间隔时长为: ${e.detail.value}ms`);
    this.setData({
      interval: e.detail.value
    })
  },
  durationChange: function (e) {
    console.log(`调整幻灯片切换时长为: ${e.detail.value}ms`);
    this.setData({
      duration: e.detail.value
    })
  },
  animationfinish: function (e) {
    console.log(e);
  },
  change: function (e) {
    console.log(e)
  },
  
  upper: function (e) {
    console.log(e)
  },
  lower: function (e) {
    console.log(e)
  },
  scroll: function (e) {
    console.log(e)
  },
  tap: function (e) {
    for (var i = 0; i < order.length; ++i) {
      if (order[i] === this.data.toView) {
        this.setData({
          toView: order[i + 1]
        })
        break
      }
    }
  },
  tapMove: function (e) {
    this.setData({
      scrollTop: this.data.scrollTop + 20
    })
  },
  onReady() {
    this.videoCtx = wx.createVideoContext('myVideo')
  },
  play() {
    this.videoCtx.play()
  },
  pause() {
    this.videoCtx.pause()
  }
})